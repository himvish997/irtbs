-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 31, 2017 at 12:43 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `irtbs`
--
CREATE DATABASE `irtbs` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `irtbs`;

-- --------------------------------------------------------

--
-- Table structure for table `userdetail`
--

CREATE TABLE `userdetail` (
  `name` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `passwd` varchar(30) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `dob` varchar(15) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` varchar(100) NOT NULL,
  `country` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userdetail`
--

INSERT INTO `userdetail` (`name`, `email`, `passwd`, `gender`, `dob`, `phone`, `address`, `country`) VALUES
('Himanshu Vishwakarma', 'himvish997@gmail.com', 'Naini@123', 'Male', '1997-03-17', '8004800324', 'Naini, Allahabad', 'country_India'),
('', '', '', '', '', '', '', ''),
('lkadjf', 'adsjflk@123', 'jj', '', '', '', '', 'country_empty'),
('jlkj', 'jasdlk@kldjs', '56', 'Male', '1099-08-08', '382970', '7439iajk', 'country_UK'),
('askldj', 'klj@123', '123', 'Male', '1999-06-04', '456789', '234567890', 'country_UK'),
('sdfghjkl', 'sdfghj@sdfghj', '123', 'Male', '2017-02-02', '1234567890', '1234567890', 'country_Germany');
